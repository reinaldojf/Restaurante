package br.edu.infnet.model.auxiliar;

public class Constante {
	public static final String NOME_RESTAURANTE = "Boteco do Man�";
}
